﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class _2dArray
    {
        static void Main(string[] args)
        {
            int[,] a = new int[3, 4];

            Console.WriteLine("LENGTH = " + a.Length);
            Console.WriteLine("Rows = " + a.GetLength(0));
            Console.WriteLine("Columns = "+a.GetLength(1));

            Console.WriteLine("Enter the elements of array");
            for(int i=0;i<a.GetLength(0);i++)
            {
                for(int j=0;j<a.GetLength(1);j++)
                {
                    a[i, j] = int.Parse(Console.ReadLine());
                }
            }
            Console.WriteLine("The elements of array");
            int sum = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    Console.Write(a[i, j]+"\t");
                    sum += a[i, j];
                }
                Console.WriteLine( " = " + sum);
                sum = 0;
            }

            sum = 0;
            for (int i = 0; i < a.GetLength(1); i++)
            {
                for (int j = 0; j < a.GetLength(0); j++)
                {
                    Console.Write(a[i, j] + "\t");
                    sum += a[ j,i];
                }
                Console.WriteLine( sum);
                sum = 0;
            }
        }
    }
}
