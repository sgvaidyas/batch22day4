﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Binarysearch
    {
        static void Main(string[] args)
        {
            int[] a = { 11, 22, 33, 44, 55, 66, 77 };

            int key, low, high, mid;
                        
            Console.WriteLine("Array elements = ");
            foreach(int x in a)
                Console.WriteLine(x);

            Console.WriteLine("Enter the key =");
            key = int.Parse(Console.ReadLine());
            
            low = 0;
            high = a.Length - 1;

            while(low<=high)
            {
                mid = (low + high) / 2;
                if (a[mid] == key)
                {
                    Console.WriteLine("Found the element at pos =" + mid);
                    break;
                }
                else if (a[mid] < key)
                {
                    low = mid + 1;
                }
                else
                    high = mid - 1;
            }
            if(low>high)
                Console.WriteLine("Search key not found");
        }
    }
}
