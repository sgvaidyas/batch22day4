﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Linearsearch_1
    {
        static void input(int[] a)
        {
            Console.WriteLine( "Enter the array elements ");
            for(int i=0;i<a.Length;i++)
                a[i] = int.Parse(Console.ReadLine());
        }
        static void output(int[] a)
        {
            Console.WriteLine("The array elements ");
            for (int i = 0; i < a.Length; i++)
                Console.WriteLine(a[i] + "\t");

        }
        static void Linearsearch(int[] a,int k)
        {
            int i,flag=0;
            for(i=0;i<a.Length;i++)
            {
                if (a[i] == k)
                {
                    Console.WriteLine("key found at " + i);
                    flag = 1;
                }
            }
            if(flag==0)
                Console.WriteLine("key not found");
            
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Enter the num of elements ");
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[n];
            input(a);
            Console.WriteLine("Enter the key ");
            int key = int.Parse(Console.ReadLine());
            /* int res= Linearsearch(a, key);
            if(res==-1)
                Console.WriteLine("Search key not found");
            else
                Console.WriteLine("Search key found at {0} index",res);
                */
            Linearsearch(a, key);

        }
    }
}
