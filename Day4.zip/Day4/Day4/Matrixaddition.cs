﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{


    class Matrixaddition
    {
        static void input(int[,] a)
        {
            int r = a.GetLength(0), c=a.GetLength(1);
            Console.WriteLine("Enter the array elements");
            for(int i=0;i<r;i++)
            {
                for(int j=0;j<c;j++)
                {
                    a[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }
        static void output(int[,] a)
        {
            int r = a.GetLength(0), c = a.GetLength(1);
            Console.WriteLine("The array elements");
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                {
                    Console.Write( a[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
        
        static void Main(string[] args)
        {
            int row, col;
            Console.WriteLine("Enter the no of rows and columns");
            row = int.Parse(Console.ReadLine());
            col = int.Parse(Console.ReadLine());
            int[,] a = new int[row, col];
            int[,] b = new int[row, col];
            int[,] c= new int[row, col];

            input(a);
            input(b);

            for(int i=0;i<a.GetLength(0);i++)
            {
                for (int j = 0;j < a.GetLength(1); j++)
                {
                    c[i, j] = a[i, j] + b[i, j];
                }
            }
            output(a);
            output(b);
            Console.WriteLine("\n\n");
            output(c);
        }
    }
}
