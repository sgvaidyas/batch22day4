﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class rightshift
    {
        static void disp(int[] a)
        {
            Console.WriteLine("Array elements  = ");
            foreach (int x in a)
                Console.Write(x + "\t");
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            int[] a = { 10, 20, 30, 40 };
            disp(a);

            int temp = a[a.Length-1];
            int n = a.Length;
            for (int i =n-2;i>=0;i--)
                a[i + 1] = a[i];

            a[0] = temp;
            disp(a);
        }
    }
}
