﻿using System;

namespace Day4
{
    class Concatarray
    {
        static void input(int[] a)
        {
            Console.WriteLine("Enter the array elements ");
            for (int i = 0; i < a.Length; i++)
                a[i] = int.Parse(Console.ReadLine());
        }
        static void output(int[] a)
        {
            Console.WriteLine("The array elements ");
            for (int i = 0; i < a.Length; i++)
                Console.WriteLine(a[i] + "\t");
        }
        static void Main(string[] args)
        {
            int n1, n2;
            Console.WriteLine("Enter the no of array elements of first array");
            n1 = int.Parse(Console.ReadLine());
            int[] a = new int[n1];
            input(a);
            Console.WriteLine("Enter the no of array elements of second array");
            n2 = int.Parse(Console.ReadLine());
            int[] b = new int[n2];
            input(b);
            int[] c = new int[n1+n2];

            for(int i=0;i<n1+n2;i++)
                 c[i] = (i < n1) ? a[i] : b[i - n1];
            output(c);
        }
    }
}
