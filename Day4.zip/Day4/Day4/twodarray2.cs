﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class twodarray2
    {
        static void input(int[,] a)
        {
            int r = a.GetLength(0), c = a.GetLength(1);
            Console.WriteLine("Enter the array elements");
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                {
                    a[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }
        static void output(int[,] a)
        {
            int r = a.GetLength(0), c = a.GetLength(1);
            Console.WriteLine("The array elements");
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < c; j++)
                {
                    Console.Write(a[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            int row, col1,col2;
            Console.WriteLine("Enter the no of rows");
            row = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the columns for first & second array");
            col1 = int.Parse(Console.ReadLine());
            col2 = int.Parse(Console.ReadLine());

            int[,] a = new int[row, col1];
            int[,] b = new int[row, col2];
            int[,] c = new int[row, col1+col2];

            input(a);
            input(b);         
            output(a);
            output(b);
            Console.WriteLine("\n\n");

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col1+col2; j++)
                {
                    c[i, j] = (j < col1) ? a[i, j] : b[i, j-col1]; 
                }
                Console.WriteLine();
            }                       
            output(c);
        }
    }
}
