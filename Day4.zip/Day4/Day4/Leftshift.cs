﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4
{
    class Leftshift
    {
        static void disp(int[] a)
        {
            Console.WriteLine("Array elements  = ");
            foreach(int x in a)
                Console.Write(x + "\t");
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            int[] a = { 10, 20, 30, 40 };
            disp(a);
             
            int temp = a[0];
            for (int i = 1; i < a.Length; i++)
                a[i - 1] = a[i];

            a[a.Length - 1] = temp;
            disp(a);
        }
    }
}
